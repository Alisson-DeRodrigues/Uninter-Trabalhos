package empresa;

public class Principal {

	public static void main(String[] args) {
		
		Menu menu = new Menu(); // instancia um menu
		menu.menuPrincipal(); // chama o menu principal
		
	}

}
